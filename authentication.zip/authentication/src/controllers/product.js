let User = require("../model/user.model")

const jwt = require('jsonwebtoken');
let generatetoken = (user)=>{
    return jwt.sign({user},"shhhh")  
}

let patch = async(req,res)=>{
    try{
         user = await User.findOne({email:req.body.email})

        if(!user){
          return res.send("Your are not allowed to post")
        }
         let token = generatetoken(user)
         user = await User.findByIdAndUpdate(req.params.id,req.body,{new:true})
        return  res.send({user,token})

    }
    catch(err){  
        console.log(err)     
    }
}

let hatao = async(req,res)=>{
    try{
         user = await User.findOne({email:req.body.email})

        if(!user){
          return res.send("Your are not allowed to post")
        }

         user = await User.findByIdAndDelete(req.params.id)
        return  res.send(user)

    }
    catch(err){  
        console.log(err)          
    }
}

module.exports = {patch,hatao}   
  