let express = require("express")

let mongoose = require("mongoose")
let bcrypt= require("bcrypt")

let userSchema = new mongoose.Schema(
    {   name:{type:String,required:true},
        email:{type:String,required:true,unique:true},
        pwd:{type:String,required:true}
    },{
        versionKey:false
    }
)

userSchema.pre("save",function(next){
    let hash = bcrypt.hashSync(this.pwd,5)
    this.pwd = hash
    return next()
})

userSchema.methods.checkpwd=function(pwd){
    return bcrypt.compareSync(pwd,this.pwd)
}

module.exports = mongoose.model("user",userSchema)