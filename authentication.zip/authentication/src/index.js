let express = require("express")

let app = express()
let connect = require("./configs/db")
let userController=require("./controllers/user.controller")
let {register,login} = require("./controllers/auth")
app.use(express.json())
let {patch,hatao} = require("./controllers/product")


app.use("/user",userController)

app.post("/login",login)

app.post("/register",register)

// app.post("/product",post)
app.patch("/product/:id",patch)
app.delete("/product/:id",hatao)  

app.listen(2000,async()=>{
    try{
      await connect()
      console.log("This is port 2000")  
    }
    catch(err){
      console.log(err)
    }
})